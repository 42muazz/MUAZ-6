import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { InfoIcon } from "lucide-react";
import { ProductDialog } from "./ProductDialog";
import { useState } from "react";

interface ProductCardProps {
  name: string;
  price: number;
  image: string;
  category: string;
  unit: string;
  description: string;
  nutrition: {
    calories: number;
    protein: number;
    carbs: number;
    fiber: number;
  };
  origin: string;
}

export function ProductCard({ name, price, image, category, unit, description, nutrition, origin }: ProductCardProps) {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <>
      <Card className="overflow-hidden transition-all hover:scale-105">
        <div className="aspect-square overflow-hidden">
          <img 
            src={image} 
            alt={name}
            className="object-cover w-full h-full hover:scale-110 transition-transform duration-300"
          />
        </div>
        <CardHeader className="p-4">
          <div className="flex justify-between items-start">
            <CardTitle className="text-lg font-semibold">{name}</CardTitle>
            <Badge 
              variant="secondary" 
              className={`${
                category === "Fruits" 
                  ? "bg-orange-600/20 text-orange-600 dark:bg-orange-400/20 dark:text-orange-400"
                  : "bg-green-600/20 text-green-600 dark:bg-green-400/20 dark:text-green-400"
              }`}
            >
              {category}
            </Badge>
          </div>
          <CardDescription className="text-2xl font-bold text-green-600 dark:text-green-400">
            ${price.toFixed(2)}/{unit}
          </CardDescription>
          <Button 
            variant="outline" 
            className="w-full mt-2 bg-green-600/10 hover:bg-green-600/20 border-green-600/20 transition-all hover:scale-105 hover:shadow-lg"
            onClick={() => setShowDetails(true)}
          >
            <InfoIcon className="w-4 h-4 mr-2" />
            More Info
          </Button>
        </CardHeader>
      </Card>

      <ProductDialog
        open={showDetails}
        onOpenChange={setShowDetails}
        product={{ name, price, image, category, unit, description, nutrition, origin }}
      />
    </>
  );
}