import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calculator } from "lucide-react";

export function CalorieCalculator() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [calories, setCalories] = useState<number | null>(null);

  const calculateCalories = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height);
    const a = parseFloat(age);

    if (w && h && a) {
      // Using Harris-Benedict equation
      const bmr = gender === "male"
        ? 88.362 + (13.397 * w) + (4.799 * h) - (5.677 * a)
        : 447.593 + (9.247 * w) + (3.098 * h) - (4.330 * a);
      
      setCalories(Math.round(bmr));
    }
  };

  return (
    <section className="py-12">
      <h2 className="text-3xl font-bold mb-8 text-center">Daily Calorie Calculator</h2>
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Calculate Your Daily Calories
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="weight">Weight (kg)</Label>
              <Input
                id="weight"
                type="number"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                className="transition-colors focus:border-green-500"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="height">Height (cm)</Label>
              <Input
                id="height"
                type="number"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                className="transition-colors focus:border-green-500"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="age">Age</Label>
              <Input
                id="age"
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="transition-colors focus:border-green-500"
              />
            </div>
            <div className="space-y-2">
              <Label>Gender</Label>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant={gender === "male" ? "default" : "outline"}
                  onClick={() => setGender("male")}
                  className="w-full transition-all hover:scale-105"
                >
                  Male
                </Button>
                <Button
                  variant={gender === "female" ? "default" : "outline"}
                  onClick={() => setGender("female")}
                  className="w-full transition-all hover:scale-105"
                >
                  Female
                </Button>
              </div>
            </div>
          </div>

          <Button 
            onClick={calculateCalories}
            className="w-full bg-green-600 hover:bg-green-700 transition-all hover:scale-105"
          >
            Calculate
          </Button>

          {calories && (
            <div className="text-center p-4 bg-green-600/10 rounded-lg">
              <p className="text-sm text-muted-foreground">Your Daily Calorie Needs:</p>
              <p className="text-2xl font-bold text-green-600">{calories} calories</p>
            </div>
          )}
        </CardContent>
      </Card>
    </section>
  );
}