import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Leaf, MapPin } from "lucide-react";

interface ProductDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product: {
    name: string;
    price: number;
    image: string;
    category: string;
    unit: string;
    description: string;
    nutrition: {
      calories: number;
      protein: number;
      carbs: number;
      fiber: number;
    };
    origin: string;
  };
}

export function ProductDialog({ open, onOpenChange, product }: ProductDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>{product.name}</span>
            <Badge variant="secondary" className="bg-orange-600/20 text-orange-600">
              {product.category}
            </Badge>
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="aspect-square overflow-hidden rounded-lg">
            <img 
              src={product.image} 
              alt={product.name}
              className="object-cover w-full h-full"
            />
          </div>
          
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Description</h3>
              <p className="text-muted-foreground">{product.description}</p>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Nutrition Facts (per 100g)</h3>
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-green-600/10 p-2 rounded">
                  <div className="text-sm text-muted-foreground">Calories</div>
                  <div className="font-semibold">{product.nutrition.calories} kcal</div>
                </div>
                <div className="bg-green-600/10 p-2 rounded">
                  <div className="text-sm text-muted-foreground">Protein</div>
                  <div className="font-semibold">{product.nutrition.protein}g</div>
                </div>
                <div className="bg-green-600/10 p-2 rounded">
                  <div className="text-sm text-muted-foreground">Carbs</div>
                  <div className="font-semibold">{product.nutrition.carbs}g</div>
                </div>
                <div className="bg-green-600/10 p-2 rounded">
                  <div className="text-sm text-muted-foreground">Fiber</div>
                  <div className="font-semibold">{product.nutrition.fiber}g</div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span>Origin: {product.origin}</span>
            </div>

            <div className="flex items-center gap-2 text-green-600">
              <Leaf className="w-4 h-4" />
              <span>100% Organic</span>
            </div>

            <div className="text-2xl font-bold text-green-600">
              ${product.price.toFixed(2)}/{product.unit}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}