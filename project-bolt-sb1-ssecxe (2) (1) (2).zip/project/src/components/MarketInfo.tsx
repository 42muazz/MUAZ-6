import { Leaf, ShoppingBasket, Truck } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function MarketInfo() {
  return (
    <div className="py-12 px-4">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">Why Choose Our Market?</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          We deliver the freshest fruits and vegetables directly from local farms to your table.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        <Card className="bg-green-600/10 border-green-600/20">
          <CardHeader>
            <Leaf className="w-12 h-12 text-green-600 dark:text-green-400 mb-4" />
            <CardTitle>Fresh & Organic</CardTitle>
            <CardDescription>100% organic produce sourced from certified local farms</CardDescription>
          </CardHeader>
        </Card>

        <Card className="bg-orange-600/10 border-orange-600/20">
          <CardHeader>
            <ShoppingBasket className="w-12 h-12 text-orange-600 dark:text-orange-400 mb-4" />
            <CardTitle>Best Prices</CardTitle>
            <CardDescription>Competitive prices with weekly special offers</CardDescription>
          </CardHeader>
        </Card>

        <Card className="bg-yellow-600/10 border-yellow-600/20">
          <CardHeader>
            <Truck className="w-12 h-12 text-yellow-600 dark:text-yellow-400 mb-4" />
            <CardTitle>Fast Delivery</CardTitle>
            <CardDescription>Same-day delivery for orders placed before 2 PM</CardDescription>
          </CardHeader>
        </Card>
      </div>
    </div>
  );
}