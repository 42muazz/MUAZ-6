import { ThemeProvider } from "@/components/theme-provider";
import { ProductCard } from "@/components/ProductCard";
import { MarketInfo } from "@/components/MarketInfo";
import { ModeToggle } from "@/components/mode-toggle";
import { CalorieCalculator } from "@/components/CalorieCalculator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const products = {
  fruits: [
    {
      name: "Fresh Avocado",
      price: 2.99,
      image: "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=500",
      category: "Fruits",
      unit: "pc",
      description: "Creamy, rich avocados perfect for guacamole, sandwiches, or as a nutritious addition to any meal. Packed with healthy fats and vitamins.",
      nutrition: { calories: 160, protein: 2, carbs: 9, fiber: 7 },
      origin: "Mexico"
    },
    {
      name: "Sweet Oranges",
      price: 4.99,
      image: "https://images.unsplash.com/photo-1547514701-42782101795e?w=500",
      category: "Fruits",
      unit: "lb",
      description: "Sweet and juicy oranges bursting with vitamin C. Perfect for fresh-squeezed juice or as a healthy snack.",
      nutrition: { calories: 47, protein: 0.9, carbs: 12, fiber: 2.4 },
      origin: "Florida, USA"
    },
    {
      name: "Bananas",
      price: 2.49,
      image: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=500",
      category: "Fruits",
      unit: "lb",
      description: "Sweet, creamy bananas perfect for snacking, baking, or adding to smoothies. Rich in potassium and fiber.",
      nutrition: { calories: 89, protein: 1.1, carbs: 23, fiber: 2.6 },
      origin: "Ecuador"
    },
    {
      name: "Fresh Strawberries",
      price: 3.99,
      image: "https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=500",
      category: "Fruits",
      unit: "lb",
      description: "Sweet and juicy strawberries, perfect for desserts or healthy snacking.",
      nutrition: { calories: 32, protein: 0.7, carbs: 7.7, fiber: 2 },
      origin: "California, USA"
    },
    {
      name: "Green Grapes",
      price: 4.49,
      image: "https://images.unsplash.com/photo-1537640538966-79f369143f8f?w=500",
      category: "Fruits",
      unit: "lb",
      description: "Crisp and sweet seedless grapes, perfect for snacking or fruit salads.",
      nutrition: { calories: 69, protein: 0.6, carbs: 18, fiber: 0.9 },
      origin: "Chile"
    }
  ],
  vegetables: [
    {
      name: "Organic Tomatoes",
      price: 3.49,
      image: "https://images.unsplash.com/photo-1524593166156-312f362cada0?w=500",
      category: "Vegetables",
      unit: "lb",
      description: "Juicy, vine-ripened tomatoes grown without pesticides. Perfect for salads, sauces, or slicing for sandwiches.",
      nutrition: { calories: 18, protein: 0.9, carbs: 3.9, fiber: 1.2 },
      origin: "California, USA"
    },
    {
      name: "Fresh Spinach",
      price: 2.29,
      image: "https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=500",
      category: "Vegetables",
      unit: "bunch",
      description: "Tender, dark green spinach leaves packed with iron and vitamins. Ideal for salads, smoothies, or cooking.",
      nutrition: { calories: 23, protein: 2.9, carbs: 3.6, fiber: 2.2 },
      origin: "Local Farm"
    },
    {
      name: "Red Bell Peppers",
      price: 1.99,
      image: "https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?w=500",
      category: "Vegetables",
      unit: "pc",
      description: "Crisp, sweet red bell peppers rich in vitamins A and C. Great for salads, stir-fries, or roasting.",
      nutrition: { calories: 31, protein: 1, carbs: 6, fiber: 2.1 },
      origin: "Netherlands"
    },
    {
      name: "Broccoli",
      price: 2.99,
      image: "https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?w=500",
      category: "Vegetables",
      unit: "lb",
      description: "Fresh, crisp broccoli florets packed with nutrients and antioxidants.",
      nutrition: { calories: 55, protein: 3.7, carbs: 11.2, fiber: 5.2 },
      origin: "Local Farm"
    },
    {
      name: "Carrots",
      price: 1.49,
      image: "https://images.unsplash.com/photo-1447175008436-054170c2e979?w=500",
      category: "Vegetables",
      unit: "lb",
      description: "Sweet and crunchy carrots, perfect for snacking or cooking.",
      nutrition: { calories: 41, protein: 0.9, carbs: 9.6, fiber: 2.8 },
      origin: "Local Farm"
    }
  ]
};

function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
      <div className="min-h-screen bg-background">
        <header className="border-b sticky top-0 bg-background/80 backdrop-blur-sm z-50">
          <div className="container mx-auto px-4 py-6 flex justify-between items-center">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-green-600 via-orange-500 to-yellow-500 text-transparent bg-clip-text">
              Fresh Market
            </h1>
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="text-orange-500 border-orange-500">
                Muaz Atalay
              </Badge>
              <ModeToggle />
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8">
          <MarketInfo />
          
          <section className="py-12">
            <h2 className="text-3xl font-bold mb-8 text-center">Our Fresh Products</h2>
            <Tabs defaultValue="fruits" className="w-full">
              <TabsList className="grid w-full grid-cols-2 max-w-[400px] mx-auto mb-8">
                <TabsTrigger value="fruits" className="data-[state=active]:bg-orange-500">Fruits</TabsTrigger>
                <TabsTrigger value="vegetables" className="data-[state=active]:bg-green-500">Vegetables</TabsTrigger>
              </TabsList>
              <TabsContent value="fruits">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {products.fruits.map((product) => (
                    <ProductCard key={product.name} {...product} />
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="vegetables">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {products.vegetables.map((product) => (
                    <ProductCard key={product.name} {...product} />
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </section>

          <CalorieCalculator />
        </main>

        <footer className="border-t py-8">
          <div className="container mx-auto px-4 text-center text-muted-foreground">
            <p>© 2024 Fresh Market. All rights reserved.</p>
          </div>
        </footer>
      </div>
    </ThemeProvider>
  );
}

export default App;